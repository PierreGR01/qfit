import unittest

from tests import _path  # noqa: F401

from qfit.visualization.application.background_map_messages import (
    build_background_map_cleared_status,
    build_background_map_failure_status,
    build_background_map_failure_title,
    build_background_map_loaded_status,
    build_background_map_result_status,
    build_styled_background_map_failure_status,
    build_styled_background_map_loaded_status,
    build_styled_visual_apply_status,
)


class BackgroundMapMessagesTests(unittest.TestCase):
    def test_build_background_map_cleared_status(self):
        self.assertEqual(
            build_background_map_cleared_status(),
            "Background map cleared",
        )

    def test_build_background_map_failure_status(self):
        self.assertEqual(
            build_background_map_failure_status(),
            "Background map could not be updated",
        )

    def test_build_background_map_failure_title(self):
        self.assertEqual(build_background_map_failure_title(), "Background map failed")

    def test_build_background_map_loaded_status(self):
        self.assertEqual(
            build_background_map_loaded_status(),
            "Background map loaded below the qfit activity layers",
        )

    def test_build_background_map_result_status_for_loaded_background(self):
        self.assertEqual(
            build_background_map_result_status(enabled=True, background_loaded=True),
            "Background map loaded below the qfit activity layers",
        )

    def test_build_background_map_result_status_for_cleared_background(self):
        self.assertEqual(
            build_background_map_result_status(enabled=False, background_loaded=False),
            "Background map cleared",
        )

    def test_build_background_map_result_status_when_enabled_but_not_loaded(self):
        self.assertEqual(
            build_background_map_result_status(enabled=True, background_loaded=False),
            "Background map cleared",
        )

    def test_build_styled_background_map_failure_status(self):
        self.assertEqual(
            build_styled_background_map_failure_status(),
            "Loaded layers with styling, but the background map could not be updated",
        )

    def test_build_styled_background_map_loaded_status(self):
        self.assertEqual(
            build_styled_background_map_loaded_status(),
            "Applied styling and loaded the background map below the qfit activity layers",
        )

    def test_build_styled_visual_apply_status(self):
        self.assertEqual(
            build_styled_visual_apply_status(),
            "Applied styling to the loaded qfit layers",
        )


if __name__ == "__main__":
    unittest.main()
