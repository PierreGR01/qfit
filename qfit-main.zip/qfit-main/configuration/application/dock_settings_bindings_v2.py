"""Refactored settings bindings using design system SettingsField."""

from __future__ import annotations

from ...design_system import (
    TextSettingsField,
    IntSettingsField,
    FloatSettingsField,
    BoolSettingsField,
    ComboBoxSettingsField,
    SettingsBinder,
)
from ...activities.domain.activity_query import DEFAULT_SORT_LABEL, DETAILED_ROUTE_FILTER_ANY
from ...detailed_route_strategy import DEFAULT_DETAILED_ROUTE_STRATEGY
from ...mapbox_config import DEFAULT_BACKGROUND_PRESET, TILE_MODE_RASTER
from ...providers.infrastructure.strava_provider import StravaProvider


DEFAULT_STYLE_PRESET = "By activity type"


def build_dock_settings_bindings_v2(dock) -> SettingsBinder:
    """Build the main dock widget settings binding table using design system.

    Returns a SettingsBinder that handles all load/save operations declaratively.
    """

    credentials_fields = [
        TextSettingsField("client_id", "", widget=dock.clientIdLineEdit),
        TextSettingsField("client_secret", "", widget=dock.clientSecretLineEdit),
        TextSettingsField(
            "redirect_uri",
            StravaProvider.DEFAULT_REDIRECT_URI,
            widget=dock.redirectUriLineEdit,
        ),
        TextSettingsField("refresh_token", "", widget=dock.refreshTokenLineEdit),
    ]

    fetch_fields = [
        TextSettingsField("output_path", dock._default_output_path(), widget=dock.outputPathLineEdit),
        IntSettingsField("per_page", 200, widget=dock.perPageSpinBox),
        IntSettingsField("max_pages", 0, widget=dock.maxPagesSpinBox),
        BoolSettingsField("use_detailed_streams", False, widget=dock.detailedStreamsCheckBox),
        IntSettingsField("max_detailed_activities", 25, widget=dock.maxDetailedActivitiesSpinBox),
        ComboBoxSettingsField(
            "detailed_route_strategy",
            DEFAULT_DETAILED_ROUTE_STRATEGY,
            widget=dock.detailedRouteStrategyComboBox,
        ),
        BoolSettingsField("write_activity_points", True, widget=dock.writeActivityPointsCheckBox),
        IntSettingsField("point_sampling_stride", 5, widget=dock.pointSamplingStrideSpinBox),
    ]

    search_filter_fields = [
        TextSettingsField("activity_search_text", "", widget=dock.activitySearchLineEdit),
        FloatSettingsField("max_distance_km", 0.0, widget=dock.maxDistanceSpinBox),
        ComboBoxSettingsField(
            "detailed_route_filter",
            DETAILED_ROUTE_FILTER_ANY,
            widget=dock.detailedRouteStatusComboBox,
            use_data=True,
        ),
    ]

    visualization_fields = [
        BoolSettingsField("use_background_map", False, widget=dock.backgroundMapCheckBox),
        TextSettingsField("mapbox_style_owner", "mapbox", widget=dock.mapboxStyleOwnerLineEdit),
        TextSettingsField("mapbox_style_id", "", widget=dock.mapboxStyleIdLineEdit),
        ComboBoxSettingsField(
            "analysis_mode",
            "None",
            widget=dock.analysisModeComboBox,
        ),
        ComboBoxSettingsField(
            "background_preset",
            DEFAULT_BACKGROUND_PRESET,
            widget=dock.backgroundPresetComboBox,
        ),
        ComboBoxSettingsField(
            "tile_mode",
            TILE_MODE_RASTER,
            widget=dock.tileModeComboBox,
        ),
        ComboBoxSettingsField(
            "preview_sort",
            DEFAULT_SORT_LABEL,
            widget=dock.previewSortComboBox,
        ),
        ComboBoxSettingsField(
            "style_preset",
            DEFAULT_STYLE_PRESET,
            widget=dock.stylePresetComboBox,
        ),
    ]

    publish_fields = [
        TextSettingsField("atlas_title", "qfit Activity Atlas", widget=dock.atlasTitleLineEdit),
        TextSettingsField("atlas_subtitle", "", widget=dock.atlasSubtitleLineEdit),
        TextSettingsField(
            "atlas_pdf_path",
            dock._default_atlas_pdf_path(),
            widget=dock.atlasPdfPathLineEdit,
        ),
    ]

    all_fields = (
        credentials_fields
        + fetch_fields
        + search_filter_fields
        + visualization_fields
        + publish_fields
    )

    return SettingsBinder(all_fields)
