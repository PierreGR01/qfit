"""Feature-oriented activity modules."""
