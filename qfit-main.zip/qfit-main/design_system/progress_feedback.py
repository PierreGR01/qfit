"""Progress feedback widget with spinner and message display."""

from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtWidgets import QFrame, QHBoxLayout, QLabel, QProgressBar, QVBoxLayout


class ProgressFeedback(QFrame):
    """Displays progress feedback during long-running operations."""

    SPINNER_CHARS = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self):
        super().__init__()
        self.is_visible = False
        self.spinner_index = 0
        self.message = ""

        self._init_ui()
        self._init_spinner()

    def _init_ui(self) -> None:
        """Initialize UI components."""
        self.setFrameStyle(QFrame.StyledPanel | QFrame.Plain)
        self.setStyleSheet("""
            ProgressFeedback {
                background-color: #F8F9FA;
                border: 1px solid #E0E0E0;
                border-radius: 4px;
                padding: 8px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # Message with spinner
        message_layout = QHBoxLayout()
        self.spinner_label = QLabel()
        self.spinner_label.setStyleSheet("font-size: 14px; color: #3498DB;")
        self.spinner_label.setFixedWidth(20)
        message_layout.addWidget(self.spinner_label)

        self.message_label = QLabel()
        self.message_label.setStyleSheet("font-size: 11px; color: #333;")
        self.message_label.setWordWrap(True)
        message_layout.addWidget(self.message_label)
        layout.addLayout(message_layout)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(0)  # Indeterminate progress
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #BDBDBD;
                border-radius: 3px;
                background-color: white;
                height: 6px;
            }
            QProgressBar::chunk {
                background-color: #3498DB;
                border-radius: 2px;
            }
        """)
        layout.addWidget(self.progress_bar)

        self.setVisible(False)

    def _init_spinner(self) -> None:
        """Initialize spinner animation."""
        self.spinner_timer = QTimer()
        self.spinner_timer.timeout.connect(self._animate_spinner)

    def _animate_spinner(self) -> None:
        """Update spinner animation."""
        self.spinner_index = (self.spinner_index + 1) % len(self.SPINNER_CHARS)
        self.spinner_label.setText(self.SPINNER_CHARS[self.spinner_index])

    def show_progress(self, message: str = "") -> None:
        """Show progress feedback with optional message."""
        self.message = message
        self.message_label.setText(message)
        self.spinner_index = 0
        self.spinner_label.setText(self.SPINNER_CHARS[0])
        self.is_visible = True
        self.setVisible(True)
        self.spinner_timer.start(100)

    def hide_progress(self, final_message: str = "") -> None:
        """Hide progress feedback with optional final message."""
        self.spinner_timer.stop()
        self.is_visible = False

        if final_message:
            self.message_label.setText(final_message)
            self.spinner_label.setText("")
            self.progress_bar.setVisible(False)
            # Auto-hide after 3 seconds
            QTimer.singleShot(3000, self._auto_hide)
        else:
            self.setVisible(False)

    def _auto_hide(self) -> None:
        """Automatically hide the feedback widget."""
        self.setVisible(False)
        self.progress_bar.setVisible(True)

    def set_progress(self, value: int, maximum: int = 100) -> None:
        """Set deterministic progress (0-100 or custom range)."""
        self.progress_bar.setMaximum(maximum)
        self.progress_bar.setValue(value)

    def reset(self) -> None:
        """Reset to initial state."""
        self.spinner_timer.stop()
        self.is_visible = False
        self.spinner_index = 0
        self.message = ""
        self.message_label.setText("")
        self.spinner_label.setText("")
        self.progress_bar.setMaximum(0)
        self.progress_bar.setValue(0)
        self.setVisible(False)
