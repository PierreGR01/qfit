"""Result indicator for success/error/warning feedback."""

from enum import Enum

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QFrame, QLabel, QVBoxLayout


class ResultType(Enum):
    """Result type indicator."""

    SUCCESS = ("✅", "#27AE60", "Success")
    ERROR = ("❌", "#E74C3C", "Error")
    WARNING = ("⚠️", "#F39C12", "Warning")
    INFO = ("ℹ️", "#3498DB", "Info")


class ResultIndicator(QFrame):
    """Displays success/error/warning results with optional suggestions."""

    def __init__(self):
        super().__init__()
        self.result_type = None
        self.message = ""
        self.suggestion = ""

        self._init_ui()

    def _init_ui(self) -> None:
        """Initialize UI components."""
        self.setFrameStyle(QFrame.StyledPanel | QFrame.Plain)
        self.setStyleSheet("ResultIndicator { border-radius: 4px; padding: 8px; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)

        # Result message
        self.message_label = QLabel()
        self.message_label.setWordWrap(True)
        self.message_label.setStyleSheet("font-weight: bold; font-size: 11px;")
        layout.addWidget(self.message_label)

        # Suggestion/detail
        self.suggestion_label = QLabel()
        self.suggestion_label.setWordWrap(True)
        self.suggestion_label.setStyleSheet("font-size: 10px; margin-top: 4px;")
        layout.addWidget(self.suggestion_label)

        self.setVisible(False)

    def set_success(self, message: str, suggestion: str = "") -> None:
        """Display success result."""
        self._set_result(ResultType.SUCCESS, message, suggestion)

    def set_error(self, message: str, suggestion: str = "") -> None:
        """Display error result."""
        self._set_result(ResultType.ERROR, message, suggestion)

    def set_warning(self, message: str, suggestion: str = "") -> None:
        """Display warning result."""
        self._set_result(ResultType.WARNING, message, suggestion)

    def set_info(self, message: str, suggestion: str = "") -> None:
        """Display info result."""
        self._set_result(ResultType.INFO, message, suggestion)

    def _set_result(
        self,
        result_type: ResultType,
        message: str,
        suggestion: str = "",
    ) -> None:
        """Set the result with type, message, and optional suggestion."""
        self.result_type = result_type
        self.message = message
        self.suggestion = suggestion

        icon, color, type_name = result_type.value

        # Update styling based on result type
        self.setStyleSheet(f"""
            ResultIndicator {{
                background-color: {self._lighten_color(color)};
                border: 1px solid {color};
                border-radius: 4px;
                padding: 8px;
            }}
        """)

        # Update message with icon
        self.message_label.setText(f"{icon} {message}")
        self.message_label.setStyleSheet(f"font-weight: bold; font-size: 11px; color: {color};")

        # Update suggestion if provided
        if suggestion:
            self.suggestion_label.setText(suggestion)
            self.suggestion_label.setStyleSheet(f"font-size: 10px; color: {color}; margin-top: 4px;")
            self.suggestion_label.setVisible(True)
        else:
            self.suggestion_label.setVisible(False)

        self.setVisible(True)

    def clear(self) -> None:
        """Clear the result indicator."""
        self.result_type = None
        self.message = ""
        self.suggestion = ""
        self.message_label.setText("")
        self.suggestion_label.setText("")
        self.setVisible(False)

    @staticmethod
    def _lighten_color(hex_color: str) -> str:
        """Lighten a hex color for background."""
        # Simple lightening: adjust hex values
        if hex_color.startswith("#") and len(hex_color) == 7:
            return hex_color + "20"  # Add alpha
        return hex_color + "20"
