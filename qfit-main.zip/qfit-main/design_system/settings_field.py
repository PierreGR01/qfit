"""Settings field bindings with declarative widget-to-settings mapping."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable

from qgis.PyQt.QtWidgets import QLineEdit, QSpinBox, QDoubleSpinBox, QCheckBox, QComboBox


@dataclass
class SettingsField(ABC):
    """Base class for settings field binding."""

    key: str
    default: Any
    validator: Callable[[Any], bool] | None = None

    @abstractmethod
    def get_value(self) -> Any:
        """Get current value from widget."""
        pass

    @abstractmethod
    def set_value(self, value: Any) -> None:
        """Set widget value."""
        pass

    def is_valid(self, value: Any) -> bool:
        """Validate value using optional validator."""
        if self.validator is None:
            return True
        return self.validator(value)


@dataclass
class TextSettingsField(SettingsField):
    """Settings field for QLineEdit."""

    widget: QLineEdit | None = None

    def get_value(self) -> str:
        return self.widget.text().strip() if self.widget else ""

    def set_value(self, value: Any) -> None:
        if self.widget:
            self.widget.setText(str(value))


@dataclass
class IntSettingsField(SettingsField):
    """Settings field for QSpinBox."""

    widget: QSpinBox | None = None

    def get_value(self) -> int:
        return self.widget.value() if self.widget else 0

    def set_value(self, value: Any) -> None:
        if self.widget:
            self.widget.setValue(int(value))


@dataclass
class FloatSettingsField(SettingsField):
    """Settings field for QDoubleSpinBox."""

    widget: QDoubleSpinBox | None = None

    def get_value(self) -> float:
        return self.widget.value() if self.widget else 0.0

    def set_value(self, value: Any) -> None:
        if self.widget:
            self.widget.setValue(float(value))


@dataclass
class BoolSettingsField(SettingsField):
    """Settings field for QCheckBox."""

    widget: QCheckBox | None = None

    def get_value(self) -> bool:
        return self.widget.isChecked() if self.widget else False

    def set_value(self, value: Any) -> None:
        if self.widget:
            self.widget.setChecked(bool(value))


@dataclass
class ComboBoxSettingsField(SettingsField):
    """Settings field for QComboBox (by text)."""

    widget: QComboBox | None = None
    use_data: bool = False  # If True, get/set by currentData instead of currentText

    def get_value(self) -> str | Any:
        if not self.widget:
            return ""
        return self.widget.currentData() if self.use_data else self.widget.currentText()

    def set_value(self, value: Any) -> None:
        if not self.widget:
            return
        if self.use_data:
            index = self.widget.findData(value)
            if index >= 0:
                self.widget.setCurrentIndex(index)
        else:
            index = self.widget.findText(str(value))
            if index >= 0:
                self.widget.setCurrentIndex(index)


class SettingsBinder:
    """Manages bidirectional binding between settings fields and a settings service."""

    def __init__(self, fields: list[SettingsField]):
        self.fields = fields

    def load(self, settings: Any) -> None:
        """Load values from settings into widgets."""
        for field in self.fields:
            value = settings.get(field.key, field.default)
            if field.is_valid(value):
                field.set_value(value)
            else:
                field.set_value(field.default)

    def save(self, settings: Any) -> None:
        """Save widget values to settings."""
        for field in self.fields:
            value = field.get_value()
            if field.is_valid(value):
                settings.set(field.key, value)
