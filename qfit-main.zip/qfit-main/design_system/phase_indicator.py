"""Visual indicator for workflow phase progress."""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QFrame, QLabel, QVBoxLayout


class PhaseIndicator(QFrame):
    """Displays current workflow phase with visual progress indication."""

    def __init__(self, current_phase: int, total_phases: int, phase_name: str = ""):
        super().__init__()
        self.current_phase = current_phase
        self.total_phases = total_phases
        self.phase_name = phase_name
        self.color = "#3498DB"  # Default blue

        self._init_ui()

    def _init_ui(self) -> None:
        """Initialize UI components."""
        self.setFrameStyle(QFrame.StyledPanel | QFrame.Plain)
        self.setStyleSheet(f"""
            PhaseIndicator {{
                background-color: {self.color};
                border-radius: 4px;
                padding: 8px;
                border: 1px solid #2980B9;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # Phase label
        self.label = QLabel()
        self.label.setStyleSheet("color: white; font-weight: bold; font-size: 12px;")
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)

        # Progress bar (visual representation)
        self.progress_label = QLabel()
        self.progress_label.setStyleSheet("color: white; font-size: 10px;")
        self.progress_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.progress_label)

        self._update_display()

    def _update_display(self) -> None:
        """Update the display with current phase information."""
        self.label.setText(f"Phase {self.current_phase}/{self.total_phases} — {self.phase_name}")
        # Create visual progress representation
        filled = "█" * self.current_phase
        empty = "░" * (self.total_phases - self.current_phase)
        self.progress_label.setText(f"{filled}{empty}")

    def set_phase(self, current_phase: int, phase_name: str = "") -> None:
        """Update to a new phase."""
        self.current_phase = current_phase
        if phase_name:
            self.phase_name = phase_name
        self._update_display()

    def set_color(self, color: str) -> None:
        """Change the indicator color (hex format like '#3498DB')."""
        self.color = color
        self.setStyleSheet(f"""
            PhaseIndicator {{
                background-color: {self.color};
                border-radius: 4px;
                padding: 8px;
                border: 1px solid {self._darken_color(color)};
            }}
        """)

    @staticmethod
    def _darken_color(hex_color: str) -> str:
        """Darken a hex color for border."""
        # Simple darkening: remove one char from brightness
        if hex_color.startswith("#") and len(hex_color) == 7:
            return hex_color[:-2] + "99"
        return hex_color
