"""Declarative visibility rules for conditional widget display."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from qgis.PyQt.QtCore import QObject
from qgis.PyQt.QtWidgets import QWidget


@dataclass
class VisibilityRule:
    """Single visibility rule: when trigger widget changes, apply condition to target widgets."""

    trigger_widget: QWidget
    target_widgets: list[QWidget]
    condition: Callable[[QWidget], bool]


class VisibilityCoordinator:
    """Coordinate conditional visibility of multiple widget groups based on trigger widgets."""

    def __init__(self, rules: list[VisibilityRule]):
        self.rules = rules
        self._setup_connections()

    def _setup_connections(self) -> None:
        """Connect trigger widgets to apply rules."""
        for rule in self.rules:
            # Connect to state changes depending on widget type
            if hasattr(rule.trigger_widget, "stateChanged"):
                rule.trigger_widget.stateChanged.connect(lambda: self._apply_rule(rule))
            elif hasattr(rule.trigger_widget, "toggled"):
                rule.trigger_widget.toggled.connect(lambda: self._apply_rule(rule))
            elif hasattr(rule.trigger_widget, "currentTextChanged"):
                rule.trigger_widget.currentTextChanged.connect(lambda: self._apply_rule(rule))
            elif hasattr(rule.trigger_widget, "currentIndexChanged"):
                rule.trigger_widget.currentIndexChanged.connect(lambda: self._apply_rule(rule))

    def _apply_rule(self, rule: VisibilityRule) -> None:
        """Apply a single rule to its target widgets."""
        should_show = rule.condition(rule.trigger_widget)
        for target in rule.target_widgets:
            target.setVisible(should_show)

    def apply_all(self) -> None:
        """Apply all rules to initialize widget visibility."""
        for rule in self.rules:
            self._apply_rule(rule)

    def add_rule(self, rule: VisibilityRule) -> None:
        """Add a new rule dynamically."""
        self.rules.append(rule)
        # Setup connection for new rule
        if hasattr(rule.trigger_widget, "stateChanged"):
            rule.trigger_widget.stateChanged.connect(lambda: self._apply_rule(rule))
        elif hasattr(rule.trigger_widget, "toggled"):
            rule.trigger_widget.toggled.connect(lambda: self._apply_rule(rule))
        # Apply immediately
        self._apply_rule(rule)
