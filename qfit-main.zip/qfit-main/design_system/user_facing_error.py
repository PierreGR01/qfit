"""User-facing error with actionable messages."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class UserFacingError:
    """Error with user-friendly message and actionable suggestion."""

    message: str  # Clear message for the user
    suggestion: str = ""  # What to do to fix it
    technical_detail: str = ""  # For logging/debug

    def __str__(self) -> str:
        """Return the user-facing message."""
        return self.message

    def full_message(self) -> str:
        """Return message with suggestion."""
        if self.suggestion:
            return f"{self.message}\n\nSuggestion: {self.suggestion}"
        return self.message

    def debug_info(self) -> str:
        """Return full debug information."""
        lines = [f"Message: {self.message}"]
        if self.suggestion:
            lines.append(f"Suggestion: {self.suggestion}")
        if self.technical_detail:
            lines.append(f"Technical: {self.technical_detail}")
        return "\n".join(lines)


class ErrorFactory:
    """Factory for creating common user-facing errors."""

    @staticmethod
    def create_api_error(
        status_code: int | None = None,
        endpoint: str = "",
        original_error: Exception | None = None,
    ) -> UserFacingError:
        """Create error for API failures."""
        if status_code == 401:
            return UserFacingError(
                message="Authentication failed",
                suggestion="Check your API credentials in Settings → Credentials",
                technical_detail=str(original_error) if original_error else "",
            )
        elif status_code == 429:
            return UserFacingError(
                message="Rate limit exceeded (too many requests)",
                suggestion="Wait a few minutes and try again",
                technical_detail=str(original_error) if original_error else "",
            )
        elif status_code == 404:
            return UserFacingError(
                message=f"Resource not found",
                suggestion="Check that the ID or endpoint is correct",
                technical_detail=str(original_error) if original_error else "",
            )
        elif status_code == 500:
            return UserFacingError(
                message="Server error (500)",
                suggestion="Try again in a few minutes or contact support",
                technical_detail=str(original_error) if original_error else "",
            )
        else:
            return UserFacingError(
                message=f"API request failed",
                suggestion="Check your connection and try again",
                technical_detail=str(original_error) if original_error else f"Status: {status_code}",
            )

    @staticmethod
    def create_connection_error(original_error: Exception | None = None) -> UserFacingError:
        """Create error for connection failures."""
        return UserFacingError(
            message="Unable to connect to the service",
            suggestion="Check your internet connection and API endpoint",
            technical_detail=str(original_error) if original_error else "",
        )

    @staticmethod
    def create_validation_error(field_name: str, reason: str = "") -> UserFacingError:
        """Create error for validation failures."""
        msg = f"Invalid value for {field_name}"
        suggestion = f"Please check {field_name}"
        if reason:
            msg += f": {reason}"
            suggestion = reason

        return UserFacingError(
            message=msg,
            suggestion=suggestion,
        )

    @staticmethod
    def create_file_error(file_path: str, operation: str, original_error: Exception | None = None) -> UserFacingError:
        """Create error for file operation failures."""
        return UserFacingError(
            message=f"Cannot {operation} file: {file_path}",
            suggestion="Check file permissions and disk space",
            technical_detail=str(original_error) if original_error else "",
        )

    @staticmethod
    def create_geometry_error() -> UserFacingError:
        """Create error for geometry issues."""
        return UserFacingError(
            message="Invalid geometries in the dataset",
            suggestion="Use Vector → Tools → Fix Geometries to correct them",
        )

    @staticmethod
    def create_custom(message: str, suggestion: str = "", technical_detail: str = "") -> UserFacingError:
        """Create custom user-facing error."""
        return UserFacingError(
            message=message,
            suggestion=suggestion,
            technical_detail=technical_detail,
        )
