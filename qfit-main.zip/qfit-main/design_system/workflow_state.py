"""Immutable workflow state and state machine for multi-phase workflows."""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

from qgis.PyQt.QtCore import QObject, pyqtSignal


class WorkflowPhase(Enum):
    """Workflow phases."""

    CONNECT = ("CONNECT", 1)
    FETCH = ("FETCH", 2)
    STORE = ("STORE", 3)
    VISUALIZE = ("VISUALIZE", 4)
    ANALYZE = ("ANALYZE", 5)
    PUBLISH = ("PUBLISH", 6)

    def __init__(self, display_name: str, phase_number: int):
        self.display_name = display_name
        self._phase_number = phase_number

    def __str__(self) -> str:
        return self.display_name

    def phase_number(self) -> int:
        return self._phase_number


@dataclass(frozen=True)
class WorkflowState:
    """Immutable representation of workflow state."""

    phase: WorkflowPhase = WorkflowPhase.CONNECT
    is_processing: bool = False
    processing_message: str = ""
    last_error: str | None = None
    last_message: str | None = None
    metadata: dict[str, Any] | None = None

    def with_phase(self, phase: WorkflowPhase) -> WorkflowState:
        return replace(self, phase=phase, is_processing=False)

    def with_processing(self, message: str = "") -> WorkflowState:
        return replace(self, is_processing=True, processing_message=message)

    def with_error(self, error: str) -> WorkflowState:
        return replace(self, is_processing=False, last_error=error)

    def with_message(self, message: str) -> WorkflowState:
        return replace(self, is_processing=False, last_message=message)

    def clear_feedback(self) -> WorkflowState:
        return replace(self, last_error=None, last_message=None)


class WorkflowStateMachine(QObject):
    """Manages workflow state transitions with validation."""

    state_changed = pyqtSignal(WorkflowState)

    def __init__(self, initial_state: WorkflowState | None = None):
        super().__init__()
        self._state = initial_state or WorkflowState()
        self._valid_transitions = {
            WorkflowPhase.CONNECT: [WorkflowPhase.FETCH],
            WorkflowPhase.FETCH: [WorkflowPhase.STORE, WorkflowPhase.CONNECT],
            WorkflowPhase.STORE: [WorkflowPhase.VISUALIZE, WorkflowPhase.CONNECT],
            WorkflowPhase.VISUALIZE: [WorkflowPhase.ANALYZE, WorkflowPhase.CONNECT],
            WorkflowPhase.ANALYZE: [WorkflowPhase.PUBLISH, WorkflowPhase.CONNECT],
            WorkflowPhase.PUBLISH: [WorkflowPhase.CONNECT],
        }

    @property
    def state(self) -> WorkflowState:
        return self._state

    def can_transition(self, target_phase: WorkflowPhase) -> bool:
        """Check if transition to target phase is valid."""
        valid_targets = self._valid_transitions.get(self._state.phase, [])
        return target_phase in valid_targets

    def transition(self, target_phase: WorkflowPhase) -> bool:
        """Attempt to transition to target phase."""
        if not self.can_transition(target_phase):
            return False
        self._state = self._state.with_phase(target_phase)
        self.state_changed.emit(self._state)
        return True

    def mark_processing(self, message: str = "") -> None:
        """Mark current phase as processing."""
        self._state = self._state.with_processing(message)
        self.state_changed.emit(self._state)

    def mark_error(self, error: str) -> None:
        """Mark current phase as failed with error message."""
        self._state = self._state.with_error(error)
        self.state_changed.emit(self._state)

    def mark_success(self, message: str) -> None:
        """Mark current phase as successful with message."""
        self._state = self._state.with_message(message)
        self.state_changed.emit(self._state)

    def reset(self) -> None:
        """Reset to initial CONNECT phase."""
        self._state = WorkflowState()
        self.state_changed.emit(self._state)
